package controllers;

import models.*;
import java.util.*;
import com.avaje.ebean.ExpressionList;
	
import play.*;
import play.data.*;
import play.data.validation.Constraints.Required;
import play.db.ebean.*;
import play.mvc.*;
		
import views.html.*;

public class Application extends Controller {
	
	public static Result index() {
		return ok(index.render("これはテンプレートのテストです。"));
	}


	
	// Message Action ====================

	// 新規投稿フォームのAction
	public static Result add(){
		Form<Message> f = new Form(Message.class);
		return ok(add.render("投稿フォーム",f));
	}
	
	public static Result create(){
		Form<Message> f = new Form(Message.class).
				bindFromRequest();
		if (!f.hasErrors()){
			Message data = f.get();
			String[] names = data.name.split(",");
			for (String nm : names) {
				Member m = Member.findByName(nm);
				data.members.add(m);
				m.messages.add(data);
			}
			data.save();
			return redirect("/");
		} else {
			return ok(add.render("ERROR", f));
		}
	}
	
	// Member Action ====================

	// メンバー作成フォームのAction
	public static Result add2(){
		Form<Member> f = new Form(Member.class);
		return ok(add2.render("メンバー登録フォーム",f));
	}
	
	// /create2にアクセスした際のAction
	public static Result create2(){
		Form<Member> f = new Form(Member.class).bindFromRequest();
		if (!f.hasErrors()){
			Member data = f.get();
			data.save();
			return redirect("/");
		} else {
			return ok(add2.render("ERROR", f));
		}
	}

}
