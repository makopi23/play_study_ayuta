package models.request.Check;

import org.junit.Test;
import play.data.Form;
import static org.fest.assertions.Assertions.assertThat;
import java.util.HashMap;
import java.util.Map;

import static play.data.Form.form;

/**
 * DESCRIPTION
 *
 * @author harakazuhiro
 * @since 2013/09/22 16:36
 */
public class ResultPostRequestTest {

    /**
     * 正しいId形式
     */
    @Test
    public void testValidationToRightParam() {
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("name", "kara_d");
        Form<ResultPostRequest> form = form(ResultPostRequest.class).bind(map);
        assertThat(form.hasErrors()).isFalse();
    }

    /**
     * アンダーバーなし
     */
    @Test
    public void testValidationToRightParamWithoutUnderBar() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("name", "karad");
        Form<ResultPostRequest> form = form(ResultPostRequest.class).bind(map);
        assertThat(form.hasErrors()).isFalse();
    }

    /**
     * 数字のみ
     */
    @Test
    public void testValidationToRightParamOnlyNumeric() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("name", "123");
        Form<ResultPostRequest> form = form(ResultPostRequest.class).bind(map);
        assertThat(form.hasErrors()).isFalse();
    }

    /**
     * 数値、英数、アンダーバー混合
     */
    @Test
    public void testValidationToRightParamWithNumeric() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("name", "kara_d_456");
        Form<ResultPostRequest> form = form(ResultPostRequest.class).bind(map);
        assertThat(form.hasErrors()).isFalse();
    }

    /**
     * ハイフンつき
     */
    @Test
    public void testValidationToWrongParamWithHyphen() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("name", "kara-d");
        Form<ResultPostRequest> form = form(ResultPostRequest.class).bind(map);
        assertThat(form.hasErrors()).isTrue();
    }

    /**
     * 禁止文字>を含む
     */
    @Test
    public void testValidationToWrongParamWithGt() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("name", "kara_>d");
        Form<ResultPostRequest> form = form(ResultPostRequest.class).bind(map);
        assertThat(form.hasErrors()).isTrue();
    }

    /**
     * ひらがなを含む
     */
    @Test
    public void testValidationToWrongParamWithHiragana() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("name", "からでぃ");
        Form<ResultPostRequest> form = form(ResultPostRequest.class).bind(map);
        assertThat(form.hasErrors()).isTrue();
    }

    /**
     * カタカナを含む
     */
    @Test
    public void testValidationToWrongParamWithKatakana() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("name", "カラディ");
        Form<ResultPostRequest> form = form(ResultPostRequest.class).bind(map);
        assertThat(form.hasErrors()).isTrue();
    }

    /**
     * 全て大文字
     */
    @Test
    public void testValidationToRightParamUpperCase() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("name", "KARA_D");
        Form<ResultPostRequest> form = form(ResultPostRequest.class).bind(map);
        assertThat(form.hasErrors()).isFalse();
    }

    /**
     * 全角英字
     */
    @Test
    public void testValidationToWrongParamZenkaku() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("name", "ｋａｒａｄ");
        Form<ResultPostRequest> form = form(ResultPostRequest.class).bind(map);
        assertThat(form.hasErrors()).isTrue();
    }

}
