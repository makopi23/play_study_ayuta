package controllers;

import models.*;
import java.util.*;

import play.*;
import play.data.*;
import play.mvc.*;


import views.html.*;

public class Application extends Controller {
	

	// フォーム管理用クラス
	public static class SampleForm {
		public List<String> inputs;
	}
	
	public static Result index() {
		List<Message> msgs = Message.find.all();
		return ok(index.render("please set form.",msgs));
	}
	
	public static Result add(){
		Form<Message> f = new Form(Message.class);
		List<Member> mems = Member.find.select("name").findList();
		return ok(add.render("投稿フォーム",f, mems));
	}

	public static Result create(){
		return redirect("/"); // ダミー処理
	}

	// Member Action ====================

	// メンバー作成フォームのAction
	public static Result add2(){
		Form<Member> f = new Form(Member.class);
		return ok(add2.render("メンバー登録フォーム",f));
	}

	// /create2にアクセスした際のAction
	public static Result create2(){
		Form<Member> f = new Form(Member.class).bindFromRequest();
		if (!f.hasErrors()){
			Member data = f.get();
			data.save();
			return redirect("/");
		} else {
			return ok(add2.render("ERROR", f));
		}
	}
}
