package models.setting;

/**
 * 診断用のステータスコード設定
 *
 * @author harakazuhiro
 * @since 2013/09/06 9:31
 */
public enum CheckYouStatusSetting {

    OK         (20, "ok."),
    NO_RESULT  (50, "no result.");

    private CheckYouStatusSetting(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    private Integer code;
    private String message;

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
