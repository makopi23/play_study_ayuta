#CheckYouサンプル

app/controllers/Checks.java がサンプルのコントローラです

## 実行方法

サンプルにカレントディレクトリを移動し、

```
$ play run -Dconfig.file=conf/application_local.conf
```

を実行、ブラウザにて「http://localhost:9000/」を開いてください

## メモ

-

# サポートサイト

Play framework 2徹底入門実践サポートサイト
http://playbook.greative.jp/
