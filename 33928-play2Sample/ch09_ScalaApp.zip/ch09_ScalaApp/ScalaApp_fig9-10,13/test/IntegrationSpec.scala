package test

import org.specs2.mutable._

import play.api.test._
import play.api.test.Helpers._

// list 7-24
class IntegrationSpec extends Specification {
  
	"Application" should {
	
		"work from within a browser" in {
			running(TestServer(3333), HTMLUNIT) { browser =>
				browser.goTo("http://localhost:3333/")
				browser.pageSource must contain("住所録一覧")
			}
		}
	
	}
  
}
