package controllers;

import models.*;

import java.util.*;

import play.*;
import play.data.*;
import play.mvc.*;
import scala.*;
import views.html.*;

import play.libs.Json;
import org.codehaus.jackson.node.ObjectNode;

import java.io.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import play.mvc.Result;

public class Application extends Controller {
	
	// フォーム管理用クラス
	public static class SampleForm {
		public List<String> inputs;
	}
	
	public static Result index() {
		List<Message> msgs = Message.find.all();
		return ok(index.render("please set form.",msgs));
	}

	public static Result ajax() {
		String input = request().body().asFormUrlEncoded().
			get("input")[0];
		Member mem = Member.findByName(input);
		DocumentBuilderFactory factory = DocumentBuilderFactory
			.newInstance();
		String str = "<xml><root><err>ERROR!</err></root>";
		Document doc = null;
		try {
			doc = factory.newDocumentBuilder()
				.newDocument();
			Element root = doc.createElement("data");
			Element el = doc.createElement("name");
			el.appendChild(doc.createTextNode(mem.name));
			root.appendChild(el);
			el = doc.createElement("mail");
			el.appendChild(doc.createTextNode(mem.mail));
			root.appendChild(el);
			el = doc.createElement("tel");
			el.appendChild(doc.createTextNode(mem.tel));
			root.appendChild(el);
			doc.appendChild(root);
			TransformerFactory tfactory = TransformerFactory
				.newInstance();
			StringWriter writer = new StringWriter();
			StreamResult stream = new StreamResult(writer);
			Transformer trans = tfactory.newTransformer();
			trans.transform(new 
				DOMSource(doc.getDocumentElement()), stream);
			str =stream.getWriter().toString();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		if(doc == null) {
			return badRequest(str);
		} else {
			return ok(str);
		}
	}
}
