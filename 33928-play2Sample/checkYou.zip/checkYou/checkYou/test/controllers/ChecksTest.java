package controllers;
import apps.FakeApp;
import com.avaje.ebean.Ebean;
import org.junit.Test;
import play.mvc.Result;

import static org.fest.assertions.Assertions.assertThat;
import static play.test.Helpers.*;
import static play.test.Helpers.fakeApplication;

/**
 * DESCRIPTION
 *
 * @author harakazuhiro
 * @since 2013/08/25 23:12
 */
public class ChecksTest extends FakeApp {
    /**
     * 通常の/へのアクセス
     * @throws Exception
     */
    @Test
    public void testIndexIsOk() throws Exception {
        Result result = route(fakeRequest(GET, "/"));
        assertThat(status(result)).isEqualTo(OK);
        assertThat(contentType(result)).isEqualTo("text/html");
        assertThat(charset(result)).isEqualTo("utf-8");
        assertThat(contentAsString(result)).contains("Twitterのユーザー名を入れてください");
    }

    /**
     * Idつきの/resultへのアクセス
     * @throws Exception
     */
    @Test
    public void testResultIdWithId() throws Exception {
        Ebean.execute(Ebean.createSqlUpdate("INSERT INTO  `checks` (`id`, `name`, `result`, `created`, `modified`) VALUES ('1',  'kara_d',  'kara_dさんにオススメなPlay frameworkのバージョンは、2.1.3 Javaです。',  '2013-08-20 12:34:56', '2013-08-20 12:34:56');"));
        Result result = route(fakeRequest(GET, "/result/1"));
        assertThat(status(result)).isEqualTo(OK);
        assertThat(contentType(result)).isEqualTo("text/html");
        assertThat(charset(result)).isEqualTo("utf-8");
        assertThat(contentAsString(result)).contains("kara_d");
    }

    /**
     * 1ページ目にはkara_aとkara_jが含まれる
     * @throws Exception
     */
    @Test
    public void testRecentShouldContainAAndJ() throws Exception {
        fixture.Check.createPaginateRecords();
        Result result = route(fakeRequest(GET, "/recent/1"));
        assertThat(status(result)).isEqualTo(OK);
        assertThat(contentType(result)).isEqualTo("text/html");
        assertThat(charset(result)).isEqualTo("utf-8");
        assertThat(contentAsString(result)).contains("kara_a");
        assertThat(contentAsString(result)).contains("kara_j");
    }

    /**
     * 1ページ目にはkara_kは含まれない
     * @throws Exception
     */
    @Test
    public void testRecentShouldNotContainK() throws Exception {
        fixture.Check.createPaginateRecords();
        Result result = route(fakeRequest(GET, "/recent/1"));
        assertThat(status(result)).isEqualTo(OK);
        assertThat(contentType(result)).isEqualTo("text/html");
        assertThat(charset(result)).isEqualTo("utf-8");
        assertThat(contentAsString(result)).doesNotContain("kara_k");
    }

    /**
     * 2ページ目は、kara_kとkara_oを含む
     * @throws Exception
     */
    @Test
    public void testRecentPage2ShouldContainKAndO() throws Exception {
        fixture.Check.createPaginateRecords();
        Result result = route(fakeRequest(GET, "/recent/2"));
        assertThat(status(result)).isEqualTo(OK);
        assertThat(contentType(result)).isEqualTo("text/html");
        assertThat(charset(result)).isEqualTo("utf-8");
        assertThat(contentAsString(result)).contains("kara_k");
        assertThat(contentAsString(result)).contains("kara_o");
    }

}
