package models.response.Check;

import java.util.Date;

/**
 * API用診断結果のレスポンスモデル
 *
 * @author harakazuhiro
 * @since 2013/08/30 18:23
 */
public class CheckResponse {
    /**
     * ID
     */
    private Long id;
    /**
     * ユーザ名
     */
    private String name;
    /**
     * 診断結果
     */
    private String result;
    /**
     * 診断日
     */
    private Date created;
    /**
     * 更新日
     */
    private Date modified;

    /**
     * デフォルトコンストラクタ
     */
    public CheckResponse() { }

    /**
     * 完全コンストラクタ
     * @param id
     * @param name
     * @param result
     * @param created
     * @param modified
     */
    public CheckResponse(Long id, String name, String result, Date created, Date modified) {
        this.id = id;
        this.name = name;
        this.result = result;
        this.created = created;
        this.modified = modified;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }
}
