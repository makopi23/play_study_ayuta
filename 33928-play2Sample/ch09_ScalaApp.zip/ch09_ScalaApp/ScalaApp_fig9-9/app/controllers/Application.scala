package controllers

import play.api._
import play.api.mvc._
import play.api.data.Form
import play.api.data.Forms._

object Application extends Controller {

  case class FormData(input:String)

  val form1 = Form(
      mapping("input" -> text)(FormData.apply)(FormData.unapply)
  )

  def index = Action {
    Ok(views.html.index("フォームを送信.", form1))
  }

  de send = Action {implicit request =>
     var resform = form1.bindFromRequest
     var res = "you typed: " + resform.getinput
     Ok(views.html.index(res, resform))
  }
}