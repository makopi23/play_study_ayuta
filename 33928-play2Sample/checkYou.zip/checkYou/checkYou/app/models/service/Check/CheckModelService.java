package models.service.Check;

import models.entity.Check;
import models.setting.CheckYouSetting;
import play.db.ebean.Model;
import models.service.Model.ModelService;
import play.libs.F;
import utils.ModelUtil;
import utils.OptionUtil;
import utils.PageUtil;

import java.util.List;

import static play.libs.F.*;

/**
 * Checkモデルのサービスクラス
 *
 * @author harakazuhiro
 * @since 2013/08/12 23:28
 */
public class CheckModelService implements ModelService<Check> {

    public static CheckModelService use() {
        return new CheckModelService();
    }

    /**
     * IDで検索
     * @param id
     * @return
     */
    @Override
    public Option<Check> findById(Long id) {
        Option<Long> idOps = OptionUtil.apply(id);
        if(idOps.isDefined()) {
            Model.Finder<Long, Check> find = ModelUtil.getFinder(Check.class);
            return OptionUtil.apply(find.byId(id));
        }
        return new None<Check>();
    }

    /**
     * 保存
     * @param entry
     * @return
     */
    @Override
    public Option<Check> save(Check entry) {
        Option<Check> entryOps = OptionUtil.apply(entry);
        if(entryOps.isDefined()) {
            entry.save();
            if(OptionUtil.apply(entry.getId()).isDefined()) {
                return OptionUtil.apply(entry);
            }
        }
        return new None<Check>();
    }

    /**
     * ページ番号で取得
     * @param pageSource
     * @return
     */
    @Override
    public Option<List<Check>> findWithPage(Integer pageSource) {
        Integer page                   = PageUtil.rightPage(pageSource);
        Model.Finder<Long, Check> find = ModelUtil.getFinder(Check.class);
        return OptionUtil.apply(
                find.order()
                        .asc("created")
                        .findPagingList(CheckYouSetting.LIMIT)
                        .getPage(page)
                        .getList());
    }

    /**
     * 最大ページ数を取得
     * @return
     */
    public Option<Integer> getMaxPage() {
        Model.Finder<Long, Check> find = ModelUtil.getFinder(Check.class);
        return OptionUtil.apply(
                find.order()
                        .asc("created")
                        .findPagingList(CheckYouSetting.LIMIT)
                        .getTotalPageCount());
    }

}
