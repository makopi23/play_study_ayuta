package controllers;

import models.*;
import java.util.*;

import play.*;
import play.data.*;
import play.mvc.*;
import scala.*;			
import views.html.*;

import play.libs.Json;
import org.codehaus.jackson.node.ObjectNode;

public class Application extends Controller {
	

	// フォーム管理用クラス
	public static class SampleForm {
		public List<String> inputs;
	}
	
	public static Result index() {
		List<Message> msgs = Message.find.all();
		return ok(index.render("please set form.",msgs));
	}
	
	public static Result ajax() {
		String input = request().body().asFormUrlEncoded()
				.get("input")[0];
		ObjectNode result = Json.newObject();
		if(input == null) {
			result.put("status", "BAD");
			result.put("message", "Can't get sending data...");
			return badRequest(result);
		} else {
			result.put("status", "OK");
			result.put("message", input);
			return ok(result);
		}
	}
}
