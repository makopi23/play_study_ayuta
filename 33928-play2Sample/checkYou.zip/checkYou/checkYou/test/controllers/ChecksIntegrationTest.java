package controllers;

import apps.FakeApp;
import org.junit.Test;
import play.libs.F;
import play.test.TestBrowser;
import java.util.HashMap;
import java.util.Map;
import static org.fest.assertions.Assertions.assertThat;
import static play.test.Helpers.*;

public class ChecksIntegrationTest {
    /**
     * 正常に判定が行われる値を入力し、送信
     * @throws Exception
     */
    @Test
    public void testResultShouldSuccessParamToName() throws Exception {
        Map<String, String> map = new HashMap<String, String>();
        map.put("checkYou.setting.message.failCheck", "診断に失敗しました");
        map.put("checkYou.setting.message.resultTitle", "さんの診断結果");
        map.putAll(inMemoryDatabase());
        running(testServer(3333, fakeApplication(map)), HTMLUNIT, new F.Callback<TestBrowser>() {
            public void invoke(TestBrowser browser) {
                FakeApp.initDb();
                browser.goTo("http://localhost:3333");
                browser.fill("#name").with("kara_d");
                browser.$("#checkYourName").submit();
                assertThat(browser.url()).contains("http://localhost:3333/result");
                assertThat(browser.$("h2#title").getText()).isEqualTo("kara_dさんの診断結果");
                assertThat(browser.$("#check-result-text").getText()).contains("kara_d");
            }
        });
    }
    /**
     * バリデーションエラーになる名前を入力し、送信
     * @throws Exception
     */
    @Test
    public void testResultShouldWrongParamToName() throws Exception {
        Map<String, String> map = new HashMap<String, String>();
        map.put("checkYou.setting.message.failCheck", "診断に失敗しました");
        map.put("checkYou.setting.message.resultTitle", "さんの診断結果");
        map.putAll(inMemoryDatabase());
        running(testServer(3333, fakeApplication(map)), HTMLUNIT, new F.Callback<TestBrowser>() {
            public void invoke(TestBrowser browser) {
                FakeApp.initDb();
                browser.goTo("http://localhost:3333");
                assertThat(browser.$("#description").getText()).isEqualTo("Twitterのユーザー名を入れてください");
                browser.fill("#name").with("kara_>d");
                browser.$("#checkYourName").submit();
                assertThat(browser.url()).contains("http://localhost:3333/result");
                assertThat(browser.$(".error strong").getText()).contains("Twitter id形式ではありません");
                assertThat(browser.$("#name").getValue()).contains("kara_>d");
            }
        });
    }

}
