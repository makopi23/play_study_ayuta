package models.setting;

/**
 * 診断用設定
 *
 * @author harakazuhiro
 * @since 2013/08/12 23:26
 */
public class CheckYouSetting {

    public final static Integer LIMIT        = 10;

}
