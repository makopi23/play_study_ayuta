package controllers.crud;

import play.mvc.*;
import views.html.crud.*;

/**
 * Controller for CRUD Top page
 */
public class TopCrudController extends Controller {

  /**
   * トップページ表示
   *
   * @return
   */
  @play.mvc.Security.Authenticated(models.crud.Secured.class)
  public static Result index() {
      return ok(top_crud.render("Top page"));
  }
}
