package models.response.Check;

import models.service.api.Check.CheckResponseService;

import java.util.List;

/**
 * API用診断結果一覧のレスポンスモデル
 *
 * @author harakazuhiro
 * @since 2013/08/30 18:21
 */
public class CheckPagingResponse {
    /**
     * エラーコード
     */
    private Integer code;
    /**
     * ステータス
     */
    private String status;
    /**
     * サーバーからのメッセージ
     */
    private String message;
    /**
     * 最大ページ数
     */
    private Integer maxPage;
    /**
     * 診断結果一覧
     */
    List<CheckResponse> results;

    /**
     * BadRequestを取得
     * @param message
     * @return
     */
    public ChecksDefaultResponse badRequest(String message) {
        return CheckResponseService.use().getBadRequest(message);
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getMaxPage() {
        return maxPage;
    }

    public void setMaxPage(Integer maxPage) {
        this.maxPage = maxPage;
    }

    public List<CheckResponse> getResults() {
        return results;
    }

    public void setResults(List<CheckResponse> results) {
        this.results = results;
    }
}
