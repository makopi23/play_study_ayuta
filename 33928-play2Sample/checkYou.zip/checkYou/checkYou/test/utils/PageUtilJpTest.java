package utils;

import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * DESCRIPTION
 *
 * @author harakazuhiro
 * @since 2013/08/25 23:24
 */
public class PageUtilJpTest {

    /**
     * ページ数が0のとき
     * @throws Exception
     */
    @Test
    public void ページ数が0のとき() throws Exception {
        assertThat(PageUtil.rightPage(0)).isEqualTo(0);
    }
    /**
     * ページ数が-1のとき
     * @throws Exception
     */
    @Test
    public void ページ数がマイナス1のとき() throws Exception {
        assertThat(PageUtil.rightPage(-1)).isEqualTo(0);
    }
    /**
     * ページ数が1のとき
     * @throws Exception
     */
    @Test
    public void ページ数が1のとき() throws Exception {
        assertThat(PageUtil.rightPage(1)).isEqualTo(0);
    }
    /**
     * ページ数が2のとき
     * @throws Exception
     */
    @Test
    public void ページ数が2のとき() throws Exception {
        assertThat(PageUtil.rightPage(2)).isEqualTo(1);
    }
    /**
     * ページ数が10のとき
     * @throws Exception
     */
    @Test
    public void ページ数が10のとき() throws Exception {
        assertThat(PageUtil.rightPage(10)).isEqualTo(9);
    }
    /**
     * ページ数がnullのとき
     * @throws Exception
     */
    @Test
    public void ページ数がnullのとき() throws Exception {
        assertThat(PageUtil.rightPage(null)).isEqualTo(0);
    }

}
