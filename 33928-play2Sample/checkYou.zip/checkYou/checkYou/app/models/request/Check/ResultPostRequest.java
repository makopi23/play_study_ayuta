package models.request.Check;

import play.data.validation.Constraints;
import play.libs.F;

import javax.validation.ConstraintValidatorContext;

/**
 * 診断リクエストのフォームモデル
 *
 * @author harakazuhiro
 * @since 2013/08/12 23:24
 */
public class ResultPostRequest {

    @Constraints.Required
    @Constraints.Pattern("[\\w]+")
    @Constraints.MaxLength(15)
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
