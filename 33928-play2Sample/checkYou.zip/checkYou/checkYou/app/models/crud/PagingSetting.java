package models.crud;

public class PagingSetting {
    public final static Integer LIMIT = 10;
}
