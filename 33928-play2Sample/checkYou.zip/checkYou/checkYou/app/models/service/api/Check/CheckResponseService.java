package models.service.api.Check;

import models.entity.Check;
import models.response.Check.CheckResponse;
import models.response.Check.ChecksDefaultResponse;
import models.setting.CheckYouSetting;
import models.setting.CheckYouStatusSetting;
import utils.OptionUtil;
import static play.libs.F.*;

/**
 * レスポンス用サービスクラス
 *
 * @author harakazuhiro
 * @since 2013/08/30 18:08
 */
public class CheckResponseService {

    public static CheckResponseService use() {
        return new CheckResponseService();
    }

    /**
     * BadRequestを受け取る
     * @param message
     * @return
     */
    public ChecksDefaultResponse getBadRequest(String message) {
        ChecksDefaultResponse result = new ChecksDefaultResponse();
        CheckYouStatusSetting status = CheckYouStatusSetting.NO_RESULT;
        result.setCode(status.getCode());
        result.setStatus(status.getMessage());
        result.setMessage(message);
        return result;
    }

    /**
     * CheckからCheckResponseレスポンスへの変換クラス
     * @param response
     * @return
     */
    public Option<CheckResponse> getCheckResponse(Check response) {
        Option<Check> checkOps = OptionUtil.apply(response);
        if(checkOps.isDefined()) {
            CheckResponse checkResponse = new CheckResponse(
                    checkOps.get().getId(),
                    checkOps.get().getName(),
                    checkOps.get().getResult(),
                    checkOps.get().getCreated(),
                    checkOps.get().getModified());
            return OptionUtil.apply(checkResponse);
        }
        return new None<CheckResponse>();
    }

}
