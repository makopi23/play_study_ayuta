package models.service.Check;
import org.junit.Test;
import utils.ConfigUtil;

import java.util.HashMap;
import java.util.Map;

import static org.fest.assertions.Assertions.assertThat;
import static play.test.Helpers.fakeApplication;
import static play.test.Helpers.inMemoryDatabase;
import static play.test.Helpers.running;

/**
 * DESCRIPTION
 *
 * @author harakazuhiro
 * @since 2013/08/25 23:24
 */
public class CheckServiceTest {
    @Test
    public void testGetResultText() throws Exception {
        Map<String, String> map = new HashMap<String, String>();
        map.put("checkyou.setting.message.result", "さんにオススメなPlay frameworkのバージョンは、");
        map.put("checkyou.setting.message.resultSuffix", "です。");
        map.putAll(inMemoryDatabase());

        running(fakeApplication(map), new Runnable() {
            public void run() {
                assertThat(new CheckService().getResultText("kara_d", "2.1.3 Java").get()).isEqualTo("kara_dさんにオススメなPlay frameworkのバージョンは、2.1.3 Javaです。");
            }
        });
    }
}
