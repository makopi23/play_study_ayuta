package controllers;

import play.mvc.Call;
import play.mvc.Controller;
import play.mvc.Result;

/**
 * Application Controller
 *
 * @author harakazuhiro
 * @since 2013/08/19 10:29
 */
public class Apps extends Controller {

    /**
     * 診断失敗時に呼び出されるコントローラ
     *
     * @param call
     * @param flashKey
     * @param flashMessage
     * @return
     */
    public static Result fail(Call call, String flashKey, String flashMessage) {
        ctx().flash().put(flashKey, flashMessage);
        return redirect(call);
    }

}
