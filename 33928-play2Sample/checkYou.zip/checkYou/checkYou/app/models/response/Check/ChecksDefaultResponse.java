package models.response.Check;

import models.entity.Check;
import static play.libs.F.*;
import models.service.api.Check.CheckResponseService;

/**
 * DESCRIPTION
 *
 * @author harakazuhiro
 * @since 2013/08/12 23:25
 */
public class ChecksDefaultResponse {
    private Integer code;
    private String status;
    private String message;
    private CheckResponse result;

    public ChecksDefaultResponse() {
    }

    /**
     * レスポンスDTOを取得
     * @param response
     * @return
     */
    public Option<CheckResponse> response(Check response) {
        return CheckResponseService.use().getCheckResponse(response);
    }

    /**
     * BadRequestを取得
     * @param message
     * @return
     */
    public ChecksDefaultResponse badRequest(String message) {
        return CheckResponseService.use().getBadRequest(message);
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public CheckResponse getResult() {
        return result;
    }

    public void setResult(CheckResponse result) {
        this.result = result;
    }

}
