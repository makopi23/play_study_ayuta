package test

import org.specs2.mutable._

import play.api.test._
import play.api.test.Helpers._

// list 7-22
/*
class ApplicationSpec extends Specification {
  
	"Application" should {
		
		"123 = 123" in {
			123 must beEqualTo(123)
		}
	
		"123 > 100" in {
			123 must be_> (100)
		}
	
		"hello contain" in {
			"Hi! hello everybody!" must contain("hello")
		}

		"good start" in {
			"good morning." must contain("good")
		}
	}
}*/

// list 7-23
class ApplicationSpec extends Specification {
  
	"Application" should {
		
		"render add page" in {
			running(FakeApplication()) {
				val home = route(FakeRequest(GET, "/add")).get
				contentAsString(home) must contain ("住所録の登録")
			}
		}
	
		"send 404 on a bad request" in {
			running(FakeApplication()) {
				route(FakeRequest(GET, "/boum")) must beNone        
			}
		}
		
		"render the index page" in {
			running(FakeApplication()) {
				val home = route(FakeRequest(GET, "/")).get
				status(home) must equalTo(OK)
				contentType(home) must beSome.which(_ == "text/html")
				contentAsString(home) must contain ("住所録一覧")
			}
		}
	}
}

